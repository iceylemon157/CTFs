//
// Created by ron on 2020-08-24.
//

#ifndef RIYADH_UTILS_H
#define RIYADH_UTILS_H

//void GetFalseFlagFoundMsg(char buffer[256])
void Msg1(char buffer[256]);

//void GetUsageMsg(char buffer[256]);
void Msg2(char buffer[256]);

void Msg3(char buffer[256]);
void Msg4(char buffer[256]);
void Msg5(char buffer[256]);
void Msg6(char buffer[256]);
void Msg7(char buffer[256]);

// Check that the user flag is correct
bool EnthalpyBasis(const char* userflag);

void CTFLearnHiddenFlag();

#endif //RIYADH_UTILS_H
